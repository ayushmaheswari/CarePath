package com.example.carepath;


import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public class fragment2 extends Fragment {
    TextView text2;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fragment2, container, false);
        text2 = view.findViewById(R.id.text2);
        getText();
        return view;
    }
    public void getText()
    {

        try {

            String resDeg = "hi this fragment is show the reserch done by our scietist and reserchers Company research is a key piece in the job search and interview process. Spend some time BEFORE the interview or employer interaction to understand what the company does and WHY you would be the right fit for a particular position";
            FileOutputStream fOut1 = getActivity().openFileOutput("resDeg.txt", Context.MODE_PRIVATE);
            fOut1.write(resDeg.getBytes());
            fOut1.close();

            FileInputStream fin = getActivity().openFileInput("resDeg.txt");
            int c;
            String temp="A : ";
            while( (c = fin.read()) != -1){
                temp = temp + (char)c;
            }
            text2.setText(temp);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
