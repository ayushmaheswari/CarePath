package com.example.carepath;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.appcompat.widget.AppCompatEditText;
import androidx.core.content.res.ResourcesCompat;

public class CustomEdit extends AppCompatEditText {
    Drawable clearButton,clearButton1;

    public CustomEdit(Context context) {
        super(context);
        init();
    }

    public CustomEdit(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init()
    {
        clearButton = ResourcesCompat.getDrawable(getResources(),R.drawable.dark,null);
        clearButton1 = ResourcesCompat.getDrawable(getResources(),R.drawable.light,null);

        addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                showButton();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        setOnTouchListener(new OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                float clearButtonStart;
                boolean isclicked = false;

                clearButtonStart = getWidth()-getPaddingEnd()-clearButton.getIntrinsicWidth();

                if(event.getX()>clearButtonStart)
                {
                    isclicked = true;
                }
                if(isclicked)
                {
                    switch (event.getAction()){
                        case MotionEvent.ACTION_DOWN:
                            getText().clear();
                            break;
                        case MotionEvent.ACTION_UP:
                            hideButton();
                            break;
                    }
                }

                return false;
            }
        });
    }

    void showButton()
    {
        setCompoundDrawablesRelativeWithIntrinsicBounds(null,null,clearButton,null);
    }
    void hideButton()
    {
        setCompoundDrawablesRelativeWithIntrinsicBounds(null,null,clearButton1,null);
    }
}