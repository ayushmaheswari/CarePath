package com.example.carepath;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class loginpage extends AppCompatActivity {

    EditText name,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginpage);
        name = findViewById(R.id.name);
        pass = findViewById(R.id.pass);
    }

    public void auth(View view) {
        if(name.getText().toString().equals("ca2") && pass.getText().toString().equals("ca2"))
        {
            //Toast.makeText(this, name+" and "+pass, Toast.LENGTH_SHORT).show();
            SharedPreferences sharedPreferences;
            sharedPreferences = getSharedPreferences("login",MODE_PRIVATE);
            sharedPreferences.edit().putString("id","1").commit();
            Intent i = new Intent(getApplicationContext(), home.class);
            startActivity(i);
        }
        else
        {
            Toast.makeText(this, "Please fill above feild", Toast.LENGTH_SHORT).show();
        }
    }
}
