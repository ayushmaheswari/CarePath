package com.example.carepath;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final SharedPreferences sharedPreferences;
        sharedPreferences = getSharedPreferences("login",MODE_PRIVATE);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (sharedPreferences.getString("id","")==""){
                    Intent i = new Intent(getApplicationContext(), loginpage.class);
                    startActivity(i);
                    finish();
                }
                else
                {

                    Intent i = new Intent(getApplicationContext(), home.class);
                    i.putExtra("id",sharedPreferences.getString("id",""));
                    startActivity(i);
                    finish();
                }

            }
        },3000);
    }
}
