package com.example.carepath;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class fragment1 extends Fragment {

    TextView text1;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fagment1, container, false);
        text1 = view.findViewById(R.id.text1);
        getText();
        return view;
    }

    public void getText()
    {

        try {

            String enter = "hi this fragment is show the enter done by company Entrepreneurial companies are entrepreneurial in nature because they have one focus in mind: making money and doing it quickly. ... At the same time, entrepreneurial companies have to work harder - and they expect you to work harder - to obtain that market share";
            FileOutputStream fOut1 = getActivity().openFileOutput("enter.txt", Context.MODE_PRIVATE);
            fOut1.write(enter.getBytes());
            fOut1.close();

            FileInputStream fin = getActivity().openFileInput("enter.txt");
            int c;
            String temp="A : ";
            while( (c = fin.read()) != -1){
                temp = temp + (char)c;
            }
            text1.setText(temp);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
