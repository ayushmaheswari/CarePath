package com.example.carepath;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class fragment3 extends Fragment {


    TextView text3;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fragment3, container, false);
        text3 = view.findViewById(R.id.text3);
        getText();
        return view;
    }

    public void getText()
    {

        try {

            String resDeg = "hi this fragment is show the complny placement Search Results\n" +
                    "Featured snippet from the web\n" +
                    "A placement is the sale of securities to a small number of private investors that is exempt from registration with the Securities and Exchange Commission under Regulation D, as are fixed annuities. This exemption makes a placement a less expensive way for a company to raise capital compared with a public offering.";
            FileOutputStream fOut1 = getActivity().openFileOutput("Cplace.txt", Context.MODE_PRIVATE);
            fOut1.write(resDeg.getBytes());
            fOut1.close();

            FileInputStream fin = getActivity().openFileInput("Cplace.txt");
            int c;
            String temp="A : ";
            while( (c = fin.read()) != -1){
                temp = temp + (char)c;
            }
            text3.setText(temp);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }


}
