package com.example.carepath;

import android.content.Context;
import android.content.SharedPreferences;

public class user {

    SharedPreferences sharedPreferences;
    Context context;
    public user(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences("login",context.MODE_PRIVATE);
    }
    public void removeUser()
    {
        sharedPreferences.edit().clear().commit();
    }


}

